"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransientError = exports.ValidationError = void 0;
/**
 * Why: Step Functions Retry/Catch can match error "names".
 * Will throw named errors so the workflow routing is deterministic.
 */
class ValidationError extends Error {
    name = "ValidationError";
}
exports.ValidationError = ValidationError;
class TransientError extends Error {
    name = "TransientError";
}
exports.TransientError = TransientError;

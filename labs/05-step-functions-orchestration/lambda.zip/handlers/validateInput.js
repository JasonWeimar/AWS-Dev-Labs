"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const errors_1 = require("../shared/errors");
/**
 * ValidateInput: boundary guard.
 * Why: Step Functions can pass anything; validate early so downstream tasks
 * don't fail with confusing errors.
 *
 * Returns: a normalized payload that becomes the workflow's canonical input.
 */
const handler = async (event) => {
    const input = event;
    if (!input?.requestId || !input?.itemId) {
        throw new errors_1.ValidationError("Missing requestId or itemId");
    }
    return {
        requestId: String(input.requestId),
        itemId: String(input.itemId),
        shouldFail: Boolean(input.shouldFail ?? false)
    };
};
exports.handler = handler;

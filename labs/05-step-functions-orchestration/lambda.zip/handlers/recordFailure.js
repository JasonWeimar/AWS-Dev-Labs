"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
/**
 * RecordFailure: Catch path target.
 * Why: In real systems- persist a failure, emit an alert, or trigger compensations.
 * For the lab- return a clean FAILED result.
 *
 * Step Functions Catch provides { Error, Cause }. Preserve Error as evidence.
 */
const handler = async (event) => {
    return {
        requestId: event.requestId ?? "UNKNOWN",
        itemId: event.itemId ?? "UNKNOWN",
        status: "FAILED",
        message: "Handled failure path",
        errorName: event.Error ?? "UnknownError"
    };
};
exports.handler = handler;

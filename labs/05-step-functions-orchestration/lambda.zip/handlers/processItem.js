"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const errors_1 = require("../shared/errors");
/**
 * ProcessItem: the "business work" step.
 * Why: Include a deterministic failure switch to prove Retry + Catch in Step E.
 */
const handler = async (event) => {
    if (event.shouldFail) {
        // Named error so Retry/Catch can match it.
        throw new errors_1.TransientError("Forced failure for Retry/Catch evidence");
    }
    return {
        requestId: event.requestId,
        itemId: event.itemId,
        status: "OK",
        message: "Processed successfully"
    };
};
exports.handler = handler;
